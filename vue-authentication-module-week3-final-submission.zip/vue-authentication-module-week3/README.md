# Vue Authentication Module – Week 6

## Deployment, Documentation & Code Review

This final version consolidates the previous VueJS work and prepares the application for a simulated production environment.

### Stack
- Vue 3
- Vue Router
- Pinia
- Vite
- Vitest + Vue Test Utils
- Docker + Nginx
- GitHub Actions

### Run locally

```bash
npm install
npm run dev
```

The terminal will display the local application URL, normally `http://localhost:5173/`.

### Test

```bash
npm test
npm run test:coverage
```

### Production build

```bash
npm run build
npm run preview
```

### Production simulation with Docker

```bash
docker build -t vue-authentication-week6 .
docker run --rm -p 8080:80 vue-authentication-week6
```

Open `http://localhost:8080`.

### CI/CD

`.github/workflows/ci.yml` runs tests, a production build, and a production-file validation on pushes and pull requests targeting `main` or `master`.

### Documentation

- `docs/DEPLOYMENT_STRATEGY.md` – deployment, monitoring, update and rollback strategy
- `docs/CODE_REVIEW_REPORT.md` – strengths, weaknesses, risks and improvements
- `docs/DEPLOYMENT_CHECKLIST.md` – release checklist
- `docs/INLINE_DOCUMENTATION_GUIDE.md` – commenting/documentation approach
- `WEEK5_UNIT_TESTING_REPORT.md` – testing report from Week 5
- `WEEK4_UI_UX_DOCUMENTATION.md` – responsive UI/UX documentation
- `WEEK3_DEBUGGING_REPORT.md` – debugging/refactoring report

### Production note

This is an internship/demo application. Client-side authentication and local storage are not sufficient for a security-sensitive production system. A real deployment should use a secure backend, HTTPS, server-side authentication/session management, monitoring, and a proper secrets strategy.
