/*
WEEK 3 BASELINE EXAMPLE
Deliberately problematic pattern documented for the exercise.

Problems:
1. Raw password persisted in localStorage.
2. JSON parsing was not protected against corrupt data.
3. localStorage exceptions were not handled.
*/

// localStorage.setItem('users', JSON.stringify(users))
// localStorage.getItem('users')
// JSON.parse(raw)
//
// A user object in the baseline could contain:
// { name, email, password }
//
// Fixed version:
// src/utils/crypto.js -> passwordHash
// src/utils/storage.js -> safe read/write/remove
// src/stores/auth.js -> normalization before reactive state
