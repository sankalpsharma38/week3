/*
WEEK 3 BASELINE EXAMPLE
Deliberately problematic redirect pattern documented for the exercise.

Problem:
A query-string redirect should not be passed directly to navigation without
checking that it is an internal path.

Unsafe pattern:
// router.push(route.query.redirect)

Fixed version:
// getSafeRedirect() accepts internal paths beginning with a single slash
// and rejects values beginning with // or non-path strings.
