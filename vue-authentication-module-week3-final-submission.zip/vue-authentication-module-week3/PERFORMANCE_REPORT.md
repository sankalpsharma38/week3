# Week 3 Performance Optimization Report

## 1. Scope

The project is a Vue 3 authentication demonstration using Pinia and Vue Router. The goal of the Week 3 work was to reduce unnecessary work, improve route loading behavior, and make authentication interactions more predictable.

## 2. Optimization changes

### Route-level lazy loading

Login, Register, and Dashboard are imported with dynamic `import()` calls in `src/router/index.js`.

This allows Vite to split route code instead of requiring every view in the initial JavaScript path.

### Validation work

Validation is split into small field-level functions. A blur event validates only the field that lost focus. Full validation occurs once on form submission.

This avoids repeatedly running unrelated validation rules while the user interacts with one field.

### Reusable field component

`AuthField.vue` centralizes the repeated label/input/error structure. This reduces duplicated template code and makes future changes easier.

### Submission guard

`isSubmitting` prevents multiple asynchronous authentication operations from being started by repeated clicks.

### State normalization

Persisted user/session data is normalized before entering reactive Pinia state. Invalid records are ignored rather than creating unstable application state.

## 3. Before / after methodology

The assignment requests browser DevTools before-and-after metrics. Exact numeric results should only be recorded from the evaluator's browser because they depend on hardware, browser version, cache state, and network conditions.

Recommended procedure:

1. Run `npm install`.
2. Run `npm run dev`.
3. Open Chrome/Edge DevTools → Performance.
4. Record a login interaction with the same test data.
5. Record a registration interaction.
6. Clear cache and reload for a comparable startup test.
7. Repeat after the refactoring.
8. Record scripting time, long tasks, and route-load observations.
9. Run Lighthouse under the same device/network settings.

### Evidence table

| Metric | Baseline | Final | How to measure |
|---|---|---|---|
| Initial page load | Record in DevTools | Record in DevTools | Performance/Lighthouse |
| Login interaction scripting | Record in DevTools | Record in DevTools | Performance recording |
| Registration interaction scripting | Record in DevTools | Record in DevTools | Performance recording |
| Long tasks | Record in DevTools | Record in DevTools | Performance recording |
| Initial JS transfer | Record in Network | Record in Network | Network tab |
| Lighthouse Performance | Record in Lighthouse | Record in Lighthouse | Same conditions |

**Important:** No invented numeric improvement is included in this report.

## 4. Expected qualitative result

The final version performs less duplicated validation work, loads authentication views through route-level chunks, avoids repeated async submissions, and keeps persistence concerns isolated in one utility module. These are code-level improvements that can be verified independently of machine-specific benchmark numbers.
