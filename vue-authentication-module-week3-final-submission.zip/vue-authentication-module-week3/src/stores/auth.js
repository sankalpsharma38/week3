/**
 * Pinia authentication store. Keeps session state and authentication actions
 * in one place so views remain focused on presentation and user interaction.
 */
import { computed, ref } from 'vue'
import { defineStore } from 'pinia'
import { hashPassword } from '../utils/crypto'
import { readJson, remove, writeJson } from '../utils/storage'

const USERS_KEY = 'users'
const SESSION_KEY = 'session'

function normalizeUser(user) {
  if (!user || typeof user !== 'object') return null

  const name = typeof user.name === 'string' ? user.name : ''
  const email = typeof user.email === 'string' ? user.email.toLowerCase() : ''
  const passwordHash = typeof user.passwordHash === 'string' ? user.passwordHash : ''

  if (!name || !email || !passwordHash) return null
  return { name, email, passwordHash }
}

export const useAuthStore = defineStore('auth', () => {
  const users = ref([])
  const currentUser = ref(null)
  const initialized = ref(false)

  const isAuthenticated = computed(() => Boolean(currentUser.value))

  function persistUsers() {
    return writeJson(USERS_KEY, users.value)
  }

  function persistSession() {
    return writeJson(SESSION_KEY, currentUser.value)
  }

  function initialize() {
    if (initialized.value) return

    const storedUsers = readJson(USERS_KEY, [])
    const storedSession = readJson(SESSION_KEY, null)

    users.value = Array.isArray(storedUsers)
      ? storedUsers.map(normalizeUser).filter(Boolean)
      : []

    currentUser.value = normalizeUser(storedSession)
    initialized.value = true
  }

  async function register({ name, email, password }) {
    initialize()

    const normalizedEmail = email.trim().toLowerCase()
    if (users.value.some(user => user.email === normalizedEmail)) {
      return { ok: false, message: 'An account with this email already exists.' }
    }

    const passwordHash = await hashPassword(password)
    const user = {
      name: name.trim(),
      email: normalizedEmail,
      passwordHash
    }

    users.value.push(user)

    if (!persistUsers()) {
      users.value.pop()
      return { ok: false, message: 'Unable to save the account in browser storage.' }
    }

    return { ok: true }
  }

  async function login(email, password) {
    initialize()

    const normalizedEmail = email.trim().toLowerCase()
    const user = users.value.find(item => item.email === normalizedEmail)

    if (!user) {
      return { ok: false, message: 'Invalid email or password.' }
    }

    const passwordHash = await hashPassword(password)

    if (passwordHash !== user.passwordHash) {
      return { ok: false, message: 'Invalid email or password.' }
    }

    currentUser.value = {
      name: user.name,
      email: user.email
    }

    if (!persistSession()) {
      currentUser.value = null
      return { ok: false, message: 'Unable to save the session in browser storage.' }
    }

    return { ok: true }
  }

  async function logout() {
    currentUser.value = null
    remove(SESSION_KEY)
  }

  initialize()

  return {
    users,
    currentUser,
    isAuthenticated,
    initialize,
    register,
    login,
    logout
  }
})