<template><footer class="site-footer"><div class="container footer-inner"><span>© 2026 VueAuth Internship Project</span><span>Vue 3 · Responsive UI/UX</span></div></footer></template>
