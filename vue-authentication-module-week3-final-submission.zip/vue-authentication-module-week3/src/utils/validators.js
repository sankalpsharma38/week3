export function validateName(value) {
  const name = value.trim()
  if (!name) return 'Name is required.'
  if (name.length < 2) return 'Name must contain at least 2 characters.'
  return ''
}

export function validateEmail(value) {
  const email = value.trim()
  if (!email) return 'Email is required.'
  const valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
  return valid ? '' : 'Enter a valid email address.'
}

export function validatePassword(value) {
  if (!value) return 'Password is required.'
  if (value.length < 8) return 'Password must contain at least 8 characters.'
  return ''
}

export function validatePasswordConfirmation(password, confirmation) {
  if (!confirmation) return 'Please confirm your password.'
  if (password !== confirmation) return 'Passwords do not match.'
  return ''
}