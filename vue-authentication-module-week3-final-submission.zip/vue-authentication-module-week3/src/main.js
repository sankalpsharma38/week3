/**
 * Application bootstrap. Creates the Vue root instance, installs Pinia for
 * shared authentication state, and installs the router before mounting.
 */
import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'
import router from './router'
import './assets/main.css'

const app = createApp(App)

app.use(createPinia())
app.use(router)
app.mount('#app')