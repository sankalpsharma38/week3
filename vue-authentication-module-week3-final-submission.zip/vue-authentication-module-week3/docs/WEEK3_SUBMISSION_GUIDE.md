# Week 3 Submission Guide

## Task
Debugging, Refactoring & Performance Optimization

## Included
- Revised VueJS application source code
- `baseline/` containing representative buggy versions used for comparison
- `BUG_FIX_MATRIX.md` mapping issues to corrected implementations
- `WEEK3_DEBUGGING_REPORT.md` with detailed debugging/refactoring discussion
- `PERFORMANCE_REPORT.md` with before/after measurement instructions and optimization analysis
- `README.md` with installation and run instructions
- PDF report in `docs/`

## Run the application
```bash
npm install
npm run dev
```

Open the local URL printed by Vite, normally `http://localhost:5173/`.

## Production build
```bash
npm run build
```

## Performance validation
Use Chrome/Edge DevTools and Lighthouse in a production build. Record actual results in `PERFORMANCE_REPORT.md`; no benchmark values are fabricated in this submission.

## Main improvements
- Centralized validation and storage utilities
- Safer authentication/session handling
- Protected routes and safe redirect handling
- Reusable Vue components
- Cleaner component responsibilities
- Lazy-loaded routes where appropriate
- Responsive and maintainable CSS
- Defensive handling of malformed local storage data
