# Week 3 Bug Fix Matrix

| Area | Original issue | Fixed approach | Benefit |
|---|---|---|---|
| Validation | Validation logic was duplicated/inconsistent | Centralized validation utilities | Consistent behavior and easier maintenance |
| Storage | Unsafe assumptions about stored JSON/session data | Defensive storage helpers with error handling | Prevents crashes from malformed data |
| Routing | Redirect behavior could accept unsafe destinations | Safe redirect utility and protected navigation | More predictable and safer navigation |
| Authentication | Authentication logic mixed with UI concerns | Pinia authentication store | Better separation of concerns |
| Components | Repeated UI/logic made maintenance harder | Reusable components such as AuthField, AuthCard and cards | Improved reusability |
| Routes | All application routes could be loaded together | Lazy-loaded route components where applicable | Reduces initial JavaScript work |
| Styling | Large, tightly coupled styles | Organized responsive CSS and reusable classes | Easier maintenance and responsive behavior |

## Baseline evidence
The `baseline/` folder contains representative buggy implementations for validation, storage, routing, and submission logic. These files are intentionally retained as comparison evidence and are not used by the production application.
